﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Person Peter = new Person("Peter", 20);
            Person George = new Person(18);
            Person Jose = new Person();

        }
    }
}
